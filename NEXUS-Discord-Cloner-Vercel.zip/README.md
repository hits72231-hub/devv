# NEXUS Discord Server Toolkit

A Vercel-ready Next.js dashboard for copying authorized Discord server structure in additive mode.

## Important limitations
- Uses a Discord **bot token** in server-side environment variables. Never put it in browser code or commit it.
- The bot must be installed in both source and destination servers.
- The bot needs `View Channels`, `Manage Channels`, and `Manage Roles` permissions. Role hierarchy may limit what it can create.
- This starter copies role names/basic role settings and categories/text/voice channel layout. It does not copy messages, members, webhooks, stickers, emojis, or all channel permission overwrites.
- Existing destination roles/channels are not deleted. This avoids the destructive behavior of the original script.
- Use only servers you own or administer. Do not use Discord user tokens/self-bots.

## Deploy to Vercel
1. Upload this project to a GitHub repository.
2. Import that repository at https://vercel.com/new.
3. In Project Settings → Environment Variables, add:
   - `DISCORD_BOT_TOKEN` — your Discord bot token
   - `CLONER_ACCESS_KEY` — a long random secret for this dashboard
4. Redeploy after adding variables.
5. Create a Discord application/bot at https://discord.com/developers/applications, invite it to both servers with the required permissions, and ensure its role is high enough in the target server.

## Run locally
Use Node.js 18+:
```bash
npm install
cp .env.example .env.local
npm run dev
```
Set real values in `.env.local`. Never share the bot token or access key.

## API note
Vercel serverless execution time limits apply. Very large servers may need a queue/worker architecture instead of one request.
