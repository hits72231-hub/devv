'use client';
import { useState } from 'react';

export default function Home() {
  const [source, setSource] = useState('');
  const [target, setTarget] = useState('');
  const [key, setKey] = useState('');
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState(null);
  const [logs, setLogs] = useState(['Workspace initialized.', 'Waiting for migration configuration…']);
  async function start(e) {
    e.preventDefault(); setBusy(true); setResult(null);
    setLogs(['Checking configuration…']);
    try {
      const r = await fetch('/api/clone', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({sourceGuildId:source.trim(),targetGuildId:target.trim(),accessKey:key}) });
      const data = await r.json();
      setResult({ok:r.ok, message:data.message || data.error || 'Request finished.'});
      setLogs(data.logs || [data.error || data.message || 'Request finished.']);
    } catch { setResult({ok:false,message:'Network error. Check your deployment and try again.'}); setLogs(['Could not reach the migration API.']); }
    finally { setBusy(false); }
  }
  return <main className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="brandIcon">N</div><div><b>NEXUS</b><span>SERVER TOOLKIT</span></div></div>
      <div className="navLabel">WORKSPACE</div>
      <div className="nav active"><span>◈</span> Migration dashboard</div>
      <div className="nav"><span>▤</span> Server structure</div>
      <div className="nav"><span>◷</span> Activity logs</div>
      <div className="sideBottom"><div className="statusDot"/> <div><b>System status</b><small>Ready for configuration</small></div></div>
    </aside>
    <section className="main">
      <header><div><div className="eyebrow">DISCORD ADMIN TOOLS / MIGRATION</div><h1>Server <em>Migration</em></h1><p>Move server structure with clarity and control.</p></div><div className="topPill"><i/> API workspace</div></header>
      <div className="hero"><div className="heroCopy"><div className="eyebrow light">STRUCTURE TRANSFER · V1.0</div><h2>Your community.<br/><span>Rebuilt with precision.</span></h2><p>Copy roles, categories and channel layouts between servers you administer. No user-token collection. No automatic deletion of destination content.</p><div className="heroFoot"><span>✦ AUTHORIZED SERVER ACCESS</span><span>•</span><span>SAFE ADDITIVE MODE</span></div></div><div className="orb"><div className="orbInner">N<span>✦</span></div><div className="orbitLabel">NEXUS / 01</div></div></div>
      <div className="sectionHead"><div><div className="eyebrow">CONFIGURATION</div><h3>Migration parameters</h3></div><span className="step">STEP 01 <b>/ 02</b></span></div>
      <form onSubmit={start}>
        <div className="formGrid">
          <label className="field"><span>01 — SOURCE SERVER ID</span><input value={source} onChange={e=>setSource(e.target.value)} placeholder="Server to copy from" required pattern="[0-9]{17,20}"/><small>Bot must be installed in this server.</small></label>
          <label className="field"><span>02 — DESTINATION SERVER ID</span><input value={target} onChange={e=>setTarget(e.target.value)} placeholder="Server to copy into" required pattern="[0-9]{17,20}"/><small>Use a server you administer.</small></label>
          <label className="field full"><span>03 — WORKSPACE ACCESS KEY</span><input value={key} onChange={e=>setKey(e.target.value)} placeholder="Enter the key configured in Vercel" type="password" required/><small>This is your own site access key, not a Discord token.</small></label>
        </div>
        <div className="warning"><span>!</span><p><b>Before you continue</b><br/>Add your Discord bot to both servers and grant only the required permissions. This tool adds structure; it does not delete existing channels or roles.</p></div>
        <button className="submit" disabled={busy}>{busy ? '◌  WORKING…' : 'START STRUCTURE MIGRATION  →'}</button>
      </form>
      {result && <div className={'result '+(result.ok?'success':'error')}>{result.ok?'✓':'!'} {result.message}</div>}
      <div className="sectionHead logHead"><div><div className="eyebrow">LIVE FEEDBACK</div><h3>Operation console</h3></div><span className="live"><i/>{busy?'RUNNING':'STANDBY'}</span></div>
      <div className="console">{logs.map((line,i)=><div key={i}><span>{String(i+1).padStart(2,'0')}</span><p>{line}</p></div>)}</div>
      <footer><span>© 2026 NEXUS TOOLKIT</span><span>BUILT FOR AUTHORIZED SERVER ADMINS</span></footer>
    </section>
  </main>;
}
