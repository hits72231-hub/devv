import "./globals.css";
export const metadata = { title: "NEXUS • Discord Server Toolkit", description: "Authorized Discord server structure migration dashboard" };
export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
