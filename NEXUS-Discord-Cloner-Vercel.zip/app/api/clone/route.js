import { NextResponse } from 'next/server';

const API = 'https://discord.com/api/v10';
async function discord(path, method='GET', body) {
  const r = await fetch(`${API}${path}`, {
    method,
    headers: { Authorization: `Bot ${process.env.DISCORD_BOT_TOKEN}`, 'Content-Type':'application/json' },
    ...(body ? { body: JSON.stringify(body) } : {}),
    cache: 'no-store'
  });
  const data = r.status === 204 ? null : await r.json().catch(()=>null);
  if (!r.ok) throw new Error(data?.message || `Discord API returned ${r.status}`);
  return data;
}
export async function POST(req) {
  const logs = [];
  try {
    if (!process.env.DISCORD_BOT_TOKEN || !process.env.CLONER_ACCESS_KEY)
      return NextResponse.json({error:'Deployment is missing DISCORD_BOT_TOKEN or CLONER_ACCESS_KEY.'},{status:500});
    const body = await req.json();
    if (!body.accessKey || body.accessKey !== process.env.CLONER_ACCESS_KEY)
      return NextResponse.json({error:'Access key is incorrect.'},{status:401});
    const sourceId = String(body.sourceGuildId || '');
    const targetId = String(body.targetGuildId || '');
    if (!/^\d{17,20}$/.test(sourceId) || !/^\d{17,20}$/.test(targetId) || sourceId === targetId)
      return NextResponse.json({error:'Enter two different, valid Discord server IDs.'},{status:400});
    logs.push('Validating bot access to source and destination…');
    const [source, target] = await Promise.all([discord(`/guilds/${sourceId}?with_counts=true`), discord(`/guilds/${targetId}?with_counts=true`)]);
    logs.push(`Source connected: ${source.name}`);
    logs.push(`Destination connected: ${target.name}`);
    logs.push('Reading source roles and channel structure…');
    const [sourceRoles, sourceChannels, targetRoles] = await Promise.all([
      discord(`/guilds/${sourceId}/roles`), discord(`/guilds/${sourceId}/channels`), discord(`/guilds/${targetId}/roles`)
    ]);
    const roleMap = new Map([['@everyone', targetId]]);
    let rolesCreated = 0, channelsCreated = 0, failed = [];
    for (const role of [...sourceRoles].filter(r=>r.name!=='@everyone' && !r.managed).sort((a,b)=>a.position-b.position)) {
      if (targetRoles.some(r=>r.name===role.name)) { roleMap.set(role.name, targetRoles.find(r=>r.name===role.name).id); continue; }
      try {
        const created = await discord(`/guilds/${targetId}/roles`, 'POST', {
          name: role.name, permissions: role.permissions, color: role.color, hoist: role.hoist,
          mentionable: role.mentionable
        });
        roleMap.set(role.name, created.id); rolesCreated++;
      } catch(e) { failed.push(`Role "${role.name}": ${e.message}`); }
    }
    const categories = sourceChannels.filter(c=>c.type===4).sort((a,b)=>a.position-b.position);
    const categoryMap = new Map();
    for (const cat of categories) {
      try {
        const existing = (await discord(`/guilds/${targetId}/channels`)).find(c=>c.type===4 && c.name===cat.name);
        if (existing) { categoryMap.set(cat.id, existing.id); continue; }
        const created = await discord(`/guilds/${targetId}/channels`, 'POST', {name:cat.name,type:4,position:cat.position});
        categoryMap.set(cat.id, created.id); channelsCreated++;
      } catch(e) { failed.push(`Category "${cat.name}": ${e.message}`); }
    }
    for (const ch of sourceChannels.filter(c=>c.type!==4).sort((a,b)=>a.position-b.position)) {
      try {
        const existingChannels = await discord(`/guilds/${targetId}/channels`);
        if (existingChannels.some(c=>c.name===ch.name && c.type===ch.type && (c.parent_id || null)===(categoryMap.get(ch.parent_id)||null))) continue;
        const payload = {name:ch.name,type:ch.type,position:ch.position};
        if (ch.parent_id && categoryMap.has(ch.parent_id)) payload.parent_id=categoryMap.get(ch.parent_id);
        if (ch.type===0) { if(ch.topic) payload.topic=ch.topic; if(ch.nsfw!==undefined) payload.nsfw=ch.nsfw; if(ch.rate_limit_per_user) payload.rate_limit_per_user=ch.rate_limit_per_user; }
        if (ch.type===2) { if(ch.bitrate) payload.bitrate=ch.bitrate; if(ch.user_limit) payload.user_limit=ch.user_limit; }
        await discord(`/guilds/${targetId}/channels`, 'POST', payload); channelsCreated++;
      } catch(e) { failed.push(`Channel "${ch.name}": ${e.message}`); }
    }
    logs.push(`Roles added: ${rolesCreated}`);
    logs.push(`Categories/channels added: ${channelsCreated}`);
    if (failed.length) logs.push(`Some items could not be copied (${failed.length}). First issue: ${failed[0]}`);
    logs.push('Finished. Existing destination items were not deleted.');
    return NextResponse.json({message:`Migration finished: ${rolesCreated} roles and ${channelsCreated} categories/channels added.`,logs});
  } catch(e) {
    logs.push(e.message || 'Unexpected error.');
    return NextResponse.json({error:`Migration failed: ${e.message || 'Unexpected error'}`,logs},{status:400});
  }
}
